package com.sun.java.swing.plaf.windows;
import javax.swing.plaf.metal.MetalLookAndFeel;

public class WindowsLookAndFeel extends MetalLookAndFeel {
    @Override
    public String getName() { return "Windows"; }
    @Override
    public String getID() { return "Windows"; }
    @Override
    public String getDescription() { return "Windows Look and Feel Stub"; }
    @Override
    public boolean isNativeLookAndFeel() { return false; }
    @Override
    public boolean isSupportedLookAndFeel() { return true; }
}
